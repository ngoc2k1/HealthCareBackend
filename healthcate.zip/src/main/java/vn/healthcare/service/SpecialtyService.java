package vn.healthcare.service;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import vn.healthcare.dto.BaseResponse;
import vn.healthcare.dto.SpecialtyRequest;
import vn.healthcare.dto.SpecialtyResponse;
import vn.healthcare.entity.Specialty;
import vn.healthcare.repository.SpecialtyRepository;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SpecialtyService {
    private final SpecialtyRepository specialtyRepository;
    private final ModelMapper mapper;

    public BaseResponse getAllSpecialty() {
        return BaseResponse.builder()
                .code(200)
                .msg("Hiển thị danh sách thành công")
                .data(specialtyRepository.findAll())
                .build();
    }

    public BaseResponse getSpecialtyById(Integer id) {
        Optional<Specialty> optionalSpecialty = specialtyRepository.findById(id);
        if (optionalSpecialty.isEmpty() ) {

            return BaseResponse.builder()
                    .code(400)
                    .msg("Chuyên môn không tồn tại")
                    .build();
        }

        return BaseResponse.builder()
                .code(200)
                .msg("Hiển thị thành công")
                .data(mapper.map(optionalSpecialty.get(), SpecialtyResponse.class))
                .build();
    }

    public BaseResponse createSpecialty(SpecialtyRequest request) {
        if (specialtyRepository.findByName(request.getName()).isPresent()) {

            return BaseResponse.builder()
                    .code(400)
                    .msg("Tên đã tồn tại")
                    .build();
        }
        Specialty specialty = Specialty.builder()
                .name(request.getName())
                .image(request.getImage())
                .build();

        specialtyRepository.save(specialty);

        return BaseResponse.builder()
                .code(200)
                .msg("Tạo thành công")
                .build();
    }

    public BaseResponse updateSpecialty(Integer id, SpecialtyRequest request) {
        Optional<Specialty> optionalSpecialtyByName = specialtyRepository.findByName(request.getName());
        if (optionalSpecialtyByName.isPresent() &&
                !optionalSpecialtyByName.get().getId().equals(id)) {

            return BaseResponse.builder()
                    .code(500)
                    .msg("Tên đã tồn tại")
                    .build();
        }

        Optional<Specialty> optionalSpecialtyById = specialtyRepository.findById(id);
        if (optionalSpecialtyById.isEmpty() ) {

            return BaseResponse.builder()
                    .code(400)
                    .msg("Chuyên môn không tồn tại")
                    .build();
        }

        Specialty specialty = optionalSpecialtyById.get();
        specialty.setImage(request.getImage());
        specialty.setName(request.getName());

        specialtyRepository.save(specialty);

        return BaseResponse.builder()
                .code(200)
                .msg("Cập nhật thành công")
                .build();
    }

    public BaseResponse deleteSpecialty(Integer id) {

        Optional<Specialty> optionalSpecialtyById = specialtyRepository.findById(id);
        if (optionalSpecialtyById.isEmpty() ) {

            return BaseResponse.builder()
                    .code(400)
                    .msg("Chuyên môn không tồn tại")
                    .build();
        }

        specialtyRepository.deleteById(id);


        return BaseResponse.builder()
                .code(200)
                .msg("Xóa thành công")
                .build();
    }
}
