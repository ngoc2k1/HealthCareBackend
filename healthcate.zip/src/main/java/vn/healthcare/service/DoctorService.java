package vn.healthcare.service;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import vn.healthcare.config.JwtProvider;
import vn.healthcare.constant.Role;
import vn.healthcare.dto.*;
import vn.healthcare.entity.Doctor;
import vn.healthcare.entity.Specialty;
import vn.healthcare.repository.DoctorRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class DoctorService {
    private final DoctorRepository doctorRepository;
    private final ModelMapper mapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;
    private final EmailService emailService;

    public PageResponse getAllDoctorBySpecialtyAndPage(Integer specialtyId, Integer page) {
        Pageable pageable = PageRequest.of(page - 1, 10, Sort.by("id").descending());
        Page<Doctor> doctorPage = doctorRepository.findAllBySpecialtyId(specialtyId, pageable);

        List<DoctorResponse> data = new ArrayList<>();

        for (Doctor doctor : doctorPage.getContent()) {
            data.add(mapper.map(doctor, DoctorResponse.class));
        }

        return PageResponse.builder()
                .code(200)
                .msg("Hiển thị danh sách thành công")
                .currentPage(page)
                .perPage(10)
                .totalPage(doctorPage.getTotalPages())
                .data(data)
                .build();
    }

    public BaseResponse login(LoginRequest request) {
        Optional<Doctor> doctorOptional = doctorRepository.findByPhoneOrEmail(request.getPhoneOrEmail());

        if (doctorOptional.isPresent()) {
            Doctor doctor = doctorOptional.get();
            if (passwordEncoder.matches(request.getPassword(), doctor.getPassword())) {
                return BaseResponse.builder()
                        .code(200)
                        .msg("Đăng nhập thành công")
                        .data(new LoginResponse(jwtProvider.generateToken(doctor.getId(), Role.DOCTOR)))
                        .build();
            }
        }

        return BaseResponse.builder()
                .code(400)
                .msg("Đăng nhập thất bại")
                .build();
    }


    public BaseResponse resetPassword(ResetPasswordRequest request) {
        Optional<Doctor> doctorOptional = doctorRepository.findByEmail(request.getEmail());
        if (doctorOptional.isPresent()) {
            Doctor doctor = doctorOptional.get();
            String code = RandomStringUtils.randomNumeric(8);
            doctor.setResetPasswordTimeExpire(LocalDateTime.now().plusMinutes(15));
            doctor.setResetPasswordCode(code);

            doctorRepository.save(doctor);

            emailService.sendMessageHtml(request.getEmail(), "Quên mật khẩu",
                    "reset-password", Collections.singletonMap("otp", code));


            return BaseResponse.builder()
                    .code(200)
                    .msg("Mã OTP đã được gửi vào email " + request.getEmail())
                    .build();
        }


        return BaseResponse.builder()
                .code(400)
                .msg("Email không tồn tại")
                .build();
    }


    public BaseResponse resetPasswordChange(ResetPasswordChangeRequest request) {
        Optional<Doctor> doctorOptional = doctorRepository
                .findByResetPasswordCode(request.getResetPasswordCode());

        if (doctorOptional.isPresent()) {
            Doctor doctor = doctorOptional.get();

            if (doctor.getResetPasswordTimeExpire().isBefore(LocalDateTime.now())) {

                return BaseResponse.builder()
                        .code(500)
                        .msg("Mã xác nhạn đã hết hạn")
                        .build();
            }

            doctor.setResetPasswordCode("");
            doctor.setPassword(passwordEncoder.encode(request.getNewPassword()));
            doctor.setResetPasswordTimeExpire(null);

            doctorRepository.save(doctor);


            return BaseResponse.builder()
                    .code(200)
                    .msg("Đặt mật khẩu mới thành công")
                    .build();
        }


        return BaseResponse.builder()
                .code(400)
                .msg("Đặt mật khẩu mới thất bại")
                .build();
    }

    public BaseResponse changePassword(ChangePasswordRequest request) {
        Integer doctorId = (Integer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Doctor doctor = doctorRepository.findById(doctorId).get();

        if (passwordEncoder.matches(request.getPassword(), doctor.getPassword())) {
            doctor.setPassword(passwordEncoder.encode(request.getNewPassword()));
            doctorRepository.save(doctor);

            return BaseResponse.builder()
                    .code(200)
                    .msg("Đổi mật khẩu thành công")
                    .build();
        }
        return BaseResponse.builder()
                .code(400)
                .msg("Mật khẩu không chính xác")
                .build();
    }


    public BaseResponse getProfile() {
        Integer doctorId = (Integer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        DoctorResponse data = mapper.map(doctorRepository.findById(doctorId).get(), DoctorResponse.class);

        Integer index = data.getBirthday().lastIndexOf("/") + 1;
        Integer age = LocalDate.now().getYear() - Integer.parseInt(data.getBirthday().substring(index));

        data.setAge(age);

        return BaseResponse.builder()
                .msg("Hiển thị thành công")
                .code(200)
                .data(data)
                .build();
    }


    public BaseResponse updateProfile(UpdateDoctorProfileRequest request) {
        Integer doctorId = (Integer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Doctor doctor = doctorRepository.findById(doctorId).get();

        doctor.setPhone(request.getPhone());
        doctor.setName(request.getName());
        doctor.setBirthday(request.getBirthday());
        doctor.setAddressTest(request.getAddressTest());
        doctor.setAvatar(request.getAvatar());
        doctor.setGender(request.getGender());

        doctor.setHealthInsurance(request.getHealthInsurance());
        doctor.setIdentityCard(request.getIdentityCard());
        doctor.setSpecialty(Specialty.builder().id(request.getSpecialtyDataId()).build());

        doctorRepository.save(doctor);

        return BaseResponse.builder()
                .msg("Cập nhật thành công")
                .code(200)
                .build();
    }

    public PageResponse getAllDoctorByPage(Integer page) {
        List<DoctorResponse> data = new ArrayList<>();
        Pageable pageable = PageRequest.of(page - 1, 10, Sort.by("id").descending());
        Page<Doctor> doctorPage = doctorRepository.findAll(pageable);

        for (Doctor doctor : doctorPage.getContent()) {
            DoctorResponse response = mapper.map(doctor, DoctorResponse.class);

            Integer index = doctor.getBirthday().lastIndexOf("/") + 1;
            Integer age = LocalDate.now().getYear() - Integer.parseInt(doctor.getBirthday().substring(index));

            response.setAge(age);
            data.add(response);
        }

        return PageResponse.builder()
                .code(200)
                .msg("Hiển thị danh sách thành công")
                .currentPage(page)
                .perPage(10)
                .totalPage(doctorPage.getTotalPages())
                .data(data)
                .build();
    }

    public BaseResponse updateDoctor(Integer id, UpdateDoctorRequest request) {
        Optional<Doctor> doctorOptional = doctorRepository.findById(id);
        if (doctorOptional.isEmpty()) {

            return BaseResponse.builder()
                    .code(400)
                    .msg("Bác sĩ không tồn tại")
                    .build();
        }

        Optional<Doctor> doctorOptionalByEmail = doctorRepository.findByEmail(request.getEmail());
        if (doctorOptionalByEmail.isPresent() &&
                !doctorOptionalByEmail.get().getId().equals(id)) {

            return BaseResponse.builder()
                    .code(500)
                    .msg("Email đã tồn tại")
                    .build();
        }

        Optional<Doctor> doctorOptionalByPhone = doctorRepository.findByPhone(request.getPhone());
        if (doctorOptionalByPhone.isPresent() &&
                !doctorOptionalByPhone.get().getId().equals(id)) {

            return BaseResponse.builder()
                    .code(600)
                    .msg("Số điện thoại đã tồn tại")
                    .build();
        }

        Doctor doctor = doctorOptional.get();

        if (Objects.nonNull(request.getPassword()) && !request.getPassword().isBlank()) {
            doctor.setPassword(passwordEncoder.encode(request.getPassword()));
        }
        doctor.setName(request.getName());
        doctor.setPhone(request.getPhone());
        doctor.setBirthday(request.getBirthday());
        doctor.setAddressTest(request.getAddressTest());
        doctor.setEmail(request.getEmail());
        doctor.setAvatar(request.getAvatar());
        doctor.setGender(request.getGender());
        doctor.setHealthInsurance(request.getHealthInsurance());
        doctor.setIdentityCard(request.getIdentityCard());
        doctor.setSpecialty(Specialty.builder().id(request.getSpecialtyId()).build());

        doctorRepository.save(doctor);

        return BaseResponse.builder()
                .msg("Cập nhật thành công")
                .code(200)
                .build();
    }

    public BaseResponse createDoctor(UpdateDoctorRequest request) {
        Optional<Doctor> doctorOptionalByPhone = doctorRepository.findByPhone(request.getPhone());
        if (doctorOptionalByPhone.isPresent()) {

            return BaseResponse.builder()
                    .code(600)
                    .msg("Số điện thoại đã tồn tại")
                    .build();
        }

        Optional<Doctor> doctorOptionalByEmail = doctorRepository.findByEmail(request.getEmail());
        if (doctorOptionalByEmail.isPresent()) {

            return BaseResponse.builder()
                    .code(500)
                    .msg("Email đã tồn tại")
                    .build();
        }
        Doctor doctor = new Doctor();

        doctor.setPassword(passwordEncoder.encode(request.getPassword()));
        doctor.setPhone(request.getPhone());
        doctor.setName(request.getName());
        doctor.setBirthday(request.getBirthday());
        doctor.setAddressTest(request.getAddressTest());
        doctor.setHealthInsurance(request.getHealthInsurance());
        doctor.setEmail(request.getEmail());
        doctor.setAvatar(request.getAvatar());
        doctor.setGender(request.getGender());
        doctor.setIdentityCard(request.getIdentityCard());
        doctor.setSpecialty(Specialty.builder().id(request.getSpecialtyId()).build());

        doctorRepository.save(doctor);

        return BaseResponse.builder()
                .msg("Tạo mới thành công")
                .code(200)
                .build();
    }

    public BaseResponse getDoctorById(Integer id) {
        Optional<Doctor> doctorOptional = doctorRepository.findById(id);
        if (doctorOptional.isEmpty()) {

            return BaseResponse.builder()
                    .code(400)
                    .msg("Bác sĩ không tồn tại")
                    .build();
        }

        DoctorResponse data = mapper.map(doctorOptional.get(), DoctorResponse.class);

        Integer index = data.getBirthday().lastIndexOf("/") + 1;
        Integer age = LocalDate.now().getYear() - Integer.parseInt(data.getBirthday().substring(index));

        data.setAge(age);

        return BaseResponse.builder()
                .msg("Hiển thị thành công")
                .code(200)
                .data(data)
                .build();
    }


    public BaseResponse deleteDoctor(Integer id) {

        Optional<Doctor> doctorOptional = doctorRepository.findById(id);
        if (doctorOptional.isEmpty() ) {

            return BaseResponse.builder()
                    .code(400)
                    .msg("Bác sĩ không tồn tại")
                    .build();
        }

        doctorRepository.deleteById(id);


        return BaseResponse.builder()
                .code(200)
                .msg("Xóa thành công")
                .build();
    }
}
