package vn.healthcare.service;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import vn.healthcare.config.JwtProvider;
import vn.healthcare.constant.Role;
import vn.healthcare.dto.*;
import vn.healthcare.entity.Patient;
import vn.healthcare.repository.PatientRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PatientService {
    private final PatientRepository patientRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;
    private final EmailService emailService;
    private final ModelMapper mapper;

    public BaseResponse register(PatientRegisterRequest request) {
        if (patientRepository.findByPhone(request.getPhone()).isPresent()) {
            return BaseResponse.builder()
                    .code(400)
                    .msg("Số điện thoại đã sử dụng")
                    .build();
        }

        if (patientRepository.findByEmail(request.getEmail()).isPresent()) {
            return BaseResponse.builder()
                    .code(400)
                    .msg("Email đã sử dụng")
                    .build();
        }

        Patient patient = new Patient();
        patient.setPhone(request.getPhone());
        patient.setPassword(passwordEncoder.encode(request.getPassword()));
        patient.setBirthday(request.getBirthday());
        patient.setGender(request.getGender());
        patient.setAddress(request.getAddress());
        patient.setName(request.getName());
        patient.setEmail(request.getEmail());

        patientRepository.save(patient);

        return BaseResponse.builder()
                .code(200)
                .msg("Đăng ký thành công")
                .build();
    }

    public BaseResponse resetPassword(ResetPasswordRequest request) {
        Optional<Patient> patientOptional = patientRepository.findByEmail(request.getEmail());
        if(patientOptional.isPresent()) {
            Patient patient = patientOptional.get();
            String code = RandomStringUtils.randomNumeric(8);
            patient.setResetPasswordCode(code);
            patient.setResetPasswordTimeExpire(LocalDateTime.now().plusMinutes(15));

            patientRepository.save(patient);

            emailService.sendMessageHtml(request.getEmail(), "Quên mật khẩu",
                    "reset-password", Collections.singletonMap("otp", code));


            return BaseResponse.builder()
                    .code(200)
                    .msg("Mã OTP đã được gửi vào email " + request.getEmail())
                    .build();
        }


        return BaseResponse.builder()
                .code(400)
                .msg("Email không tồn tại")
                .build();
    }


    public BaseResponse resetPasswordChange(ResetPasswordChangeRequest request) {
        Optional<Patient> patientOptional = patientRepository
                .findByResetPasswordCode(request.getResetPasswordCode());

        if(patientOptional.isPresent()) {
            Patient patient = patientOptional.get();

            if(patient.getResetPasswordTimeExpire().isBefore(LocalDateTime.now())) {

                return BaseResponse.builder()
                        .code(500)
                        .msg("Mã xác nhạn đã hết hạn")
                        .build();
            }

            patient.setPassword(passwordEncoder.encode(request.getNewPassword()));
            patient.setResetPasswordCode("");
            patient.setResetPasswordTimeExpire(null);

            patientRepository.save(patient);


            return BaseResponse.builder()
                    .code(200)
                    .msg("Đặt mật khẩu mới thành công")
                    .build();
        }


        return BaseResponse.builder()
                .code(400)
                .msg("Đặt mật khẩu mới thất bại")
                .build();
    }


    public BaseResponse changePassword(ChangePasswordRequest request) {
        Integer patientId = (Integer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Patient patient = patientRepository.findById(patientId).get();

        if (passwordEncoder.matches(request.getPassword(), patient.getPassword())) {
            patient.setPassword(passwordEncoder.encode(request.getNewPassword()));

            patientRepository.save(patient);

            return BaseResponse.builder()
                    .code(200)
                    .msg("Đổi mật khẩu thành công")
                    .build();
        }

        return BaseResponse.builder()
                .code(400)
                .msg("Mật khẩu không chính xác")
                .build();
    }


    public BaseResponse login(LoginRequest request) {
        Optional<Patient> patientOptional = patientRepository.findByPhoneOrEmail(request.getPhoneOrEmail());

        if (patientOptional.isPresent()) {
            Patient patient = patientOptional.get();
            if (passwordEncoder.matches(request.getPassword(), patient.getPassword())) {
                return BaseResponse.builder()
                        .code(200)
                        .msg("Đăng nhập thành công")
                        .data(new LoginResponse(jwtProvider.generateToken(patient.getId(), Role.PATIENT)))
                        .build();
            }
        }

        return BaseResponse.builder()
                .code(400)
                .msg("Đăng nhập thất bại")
                .build();
    }

    public BaseResponse getAllPatientBookedByDoctor() {
        Integer doctorId = (Integer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        List<Patient> patients = patientRepository.findAllPatientBookedByDoctor(doctorId);

        List<PatientResponse> data = new ArrayList<>();

        for(Patient patient : patients) {
            data.add(mapper.map(patient, PatientResponse.class));
        }

        return BaseResponse.builder()
                .msg("Hiển thị thành công")
                .code(200)
                .data(data)
                .build();
    }


    public BaseResponse getProfile() {
        Integer patientId = (Integer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        PatientResponse data = mapper.map(patientRepository.findById(patientId).get(), PatientResponse.class);

        Integer index = data.getBirthday().lastIndexOf("/") + 1;
        Integer age = LocalDate.now().getYear() - Integer.parseInt(data.getBirthday().substring(index));

        data.setAge(age);

        return BaseResponse.builder()
                .msg("Hiển thị thành công")
                .code(200)
                .data(data)
                .build();
    }


    public BaseResponse updateProfile(UpdatePatientRequest request) {
        Integer patientId = (Integer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Patient patient = patientRepository.findById(patientId).get();

        patient.setPhone(request.getPhone());
        patient.setName(request.getName());
        patient.setAvatar(request.getAvatar());
        patient.setBirthday(request.getBirthday());
        patient.setAddress(request.getAddress());
        patient.setGender(request.getGender());

        patient.setHealthInsurance(request.getHealthInsurance());
        patient.setIdentityCard(request.getIdentityCard());
//        patient.setAge(request.getAge());
        patient.setWeight(request.getWeight());
        patient.setHeight(request.getHeight());
        patient.setBloodGroup(request.getBloodGroup());

        patientRepository.save(patient);

        return BaseResponse.builder()
                .msg("Cập nhật thành công")
                .code(200)
                .build();
    }
}
