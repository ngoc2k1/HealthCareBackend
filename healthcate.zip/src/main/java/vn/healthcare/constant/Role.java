package vn.healthcare.constant;

public class Role {
    public static final String PATIENT = "PATIENT";
    public static final String DOCTOR = "DOCTOR";
    public static final String ADMIN = "ADMIN";
}
