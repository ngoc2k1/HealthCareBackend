package vn.healthcare.constant;

public enum BloodGroup {
    A,B,AB,O
}
