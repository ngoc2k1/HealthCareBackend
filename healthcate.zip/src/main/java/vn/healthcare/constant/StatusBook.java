package vn.healthcare.constant;

public enum StatusBook {
    CHUA_KHAM,
    DA_KHAM,
    DA_HUY
}
