package vn.healthcare.constant;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
