package vn.healthcare.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import vn.healthcare.dto.BaseResponse;
import vn.healthcare.dto.LoginRequest;
import vn.healthcare.service.AdminService;

@RestController
@RequestMapping("/v1")
@RequiredArgsConstructor
public class AdminController {
    private final AdminService adminService;

    // New
    @PostMapping("/admin/login")
    public BaseResponse login(@RequestBody LoginRequest loginRequest) {
        return adminService.login(loginRequest);
    }

}
