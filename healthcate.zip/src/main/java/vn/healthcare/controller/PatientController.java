package vn.healthcare.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import vn.healthcare.dto.*;
import vn.healthcare.service.BookScheduleService;
import vn.healthcare.service.PatientService;

import javax.validation.Valid;

@RestController
@RequestMapping("/v1")
@RequiredArgsConstructor
public class PatientController {
    private final PatientService patientService;
    private final BookScheduleService bookScheduleService;

    // Api của BS xem danh sách BN đặt khám
    // Passed
    // Done
    @PreAuthorize("hasAuthority('DOCTOR')")
    @GetMapping("/list-patient")
    public BaseResponse getAllPatientBookedByDoctor() {
        return patientService.getAllPatientBookedByDoctor();
    }

    // Passed
    // Done
    @PreAuthorize("hasAuthority('PATIENT')")
    @GetMapping("/patient")
    public BaseResponse getPatientProfile() {
        return patientService.getProfile();
    }

    // Passed
    // Done
    @PreAuthorize("hasAuthority('PATIENT')")
    @PutMapping("/patient/update")
    public BaseResponse updatePatientProfile(@RequestBody UpdatePatientRequest request) {
        return patientService.updateProfile(request);
    }

    // Passed
    // Done
    @PreAuthorize("hasAuthority('PATIENT')")
    @GetMapping("/patient/notification")
    public BaseResponse getPatientNotification() {
        return bookScheduleService.getNotificationForPatient();
    }

    // Passed
    // Done
    @PostMapping("/patient/register")
    public BaseResponse register(@RequestBody PatientRegisterRequest registerRequest) {
        return patientService.register(registerRequest);
    }

    // Passed
    // Done
    @PostMapping("/patient/login")
    public BaseResponse login(@RequestBody LoginRequest loginRequest) {
        return patientService.login(loginRequest);
    }


    // Passed
    // Done
    @PostMapping("/patient/reset-password")
    public BaseResponse resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        return patientService.resetPassword(request);
    }


    // Passed
    // Done
    @PutMapping("/patient/reset-password")
    public BaseResponse resetPasswordChange(@Valid @RequestBody ResetPasswordChangeRequest request) {
        return patientService.resetPasswordChange(request);
    }


    // Passed
    // Done
    @PreAuthorize("isAuthenticated()")
    @PutMapping("/patient/change-password")
    public BaseResponse changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        return patientService.changePassword(request);
    }

}
