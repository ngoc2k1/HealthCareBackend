package vn.healthcare.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import vn.healthcare.dto.BaseResponse;
import vn.healthcare.dto.CreateScheduleRequest;
import vn.healthcare.dto.PageResponse;
import vn.healthcare.dto.UpdateScheduleRequest;
import vn.healthcare.service.BookScheduleService;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1")
public class BookScheduleController {
    private final BookScheduleService bookScheduleService;

    // Passed
    // Api của BS xem danh sách lịch khám
    // Done
    @PreAuthorize("hasAuthority('DOCTOR')")
    @GetMapping("/list-book-schedule-by-doctor")
    public BaseResponse getAllScheduleByDoctor() {
        return bookScheduleService.getAllScheduleByDoctor();
    }


    // Passed
    // Api của BN xem danh sách lịch khám
    // Done
    @PreAuthorize("hasAuthority('PATIENT')")
    @GetMapping("/list-book-schedule-by-patient")
    public PageResponse getAllScheduleByPatient(@RequestParam(defaultValue = "1") Integer page) {
        return bookScheduleService.getAllScheduleByPatient(page);
    }

    // Passed
    // Api của BN xem chi tiết lịch khám
    // Done
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/book-schedule/detail/{id}")
    public BaseResponse getDetailSchedule(@PathVariable Integer id) {
        return bookScheduleService.getBookScheduleDetail(id);
    }

    // Passed
    // Done
    @PreAuthorize("hasAuthority('DOCTOR')")
    @PutMapping("/book-schedule/confirm/{id}")
    public BaseResponse confirmBookSchedule(@PathVariable Integer id) {
        return bookScheduleService.confirm(id);
    }


    // Passed
    // Done
    @PreAuthorize("hasAuthority('PATIENT')")
    @PutMapping("/book-schedule/cancel/{scheduleId}")
    public BaseResponse cancelBookSchedule(@PathVariable Integer scheduleId) {
        return bookScheduleService.cancelSchedule(scheduleId);
    }


    // Passed
    // Done
    @PreAuthorize("hasAuthority('PATIENT')")
    @PutMapping("/book-schedule/update/{id}")
    public BaseResponse updateBookSchedule(@PathVariable Integer id,
                                           @RequestBody UpdateScheduleRequest request) {
        return bookScheduleService.updateSchedule(id, request);
    }

    // Passed
    // Done
    @PreAuthorize("hasAuthority('PATIENT')")
    @PostMapping("/book-schedule/create")
    public BaseResponse createBookSchedule(@RequestBody CreateScheduleRequest request) {
        return bookScheduleService.createSchedule(request);
    }
}
