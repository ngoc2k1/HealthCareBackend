package vn.healthcare.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import vn.healthcare.dto.*;
import vn.healthcare.service.BookScheduleService;
import vn.healthcare.service.DoctorService;

import javax.validation.Valid;

@RestController
@RequestMapping("/v1")
@RequiredArgsConstructor
public class DoctorController {
    private final DoctorService doctorService;
    private final BookScheduleService bookScheduleService;

    // Passed
    // Done
    @GetMapping("/doctor-by-specialty/{id}")
    public PageResponse getDoctorBySpecialty(@PathVariable Integer id,
                                             @RequestParam(defaultValue = "1") Integer page) {
        return doctorService.getAllDoctorBySpecialtyAndPage(id, page);
    }

    // Passed
    // Done
    @GetMapping("/doctor")
    @PreAuthorize("hasAuthority('DOCTOR')")
    public BaseResponse getDoctorProfile() {
        return doctorService.getProfile();
    }

    // Passed
    // Done
    @PreAuthorize("hasAuthority('DOCTOR')")
    @PutMapping("/doctor/update")
    public BaseResponse updateDoctorProfile(@RequestBody UpdateDoctorProfileRequest request) {
        return doctorService.updateProfile(request);
    }

    // Passed
    // Done
    @PreAuthorize("hasAuthority('DOCTOR')")
    @GetMapping("/doctor/notification")
    public PageResponse getDoctorNotification(@RequestParam(defaultValue = "1") Integer page) {
        return bookScheduleService.getNotificationForDoctor(page);
    }

    // Passed
    // Done
    @PostMapping("/doctor/login")
    public BaseResponse login(@RequestBody LoginRequest loginRequest) {
        return doctorService.login(loginRequest);
    }


    // Passed
    // Done
    @PostMapping("/doctor/reset-password")
    public BaseResponse resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        return doctorService.resetPassword(request);
    }


    // Passed
    // Done
    @PutMapping("/doctor/reset-password")
    public BaseResponse resetPasswordChange(@Valid @RequestBody ResetPasswordChangeRequest request) {
        return doctorService.resetPasswordChange(request);
    }


    // Passed
    // Done
    @PutMapping("/doctor/change-password")
    public BaseResponse changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        return doctorService.changePassword(request);
    }

    // New
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/list-doctor")
    public PageResponse getAllDoctorByPage(@RequestParam(defaultValue = "1") Integer page) {
        return doctorService.getAllDoctorByPage(page);
    }


    // New
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/doctor/{id}")
    public BaseResponse getDoctorById(@PathVariable Integer id) {
        return doctorService.getDoctorById(id);
    }

    // New
    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("/doctor/update/{id}")
    public BaseResponse updateDoctor(@PathVariable Integer id,
                                     @Valid @RequestBody UpdateDoctorRequest request) {
        return doctorService.updateDoctor(id, request);
    }

    // New
    @PreAuthorize("hasAuthority('ADMIN')")
    @PostMapping("/doctor/create")
    public BaseResponse createDoctor(@Valid @RequestBody UpdateDoctorRequest request) {
        return doctorService.createDoctor(request);
    }

    // New
    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("/doctor/delete/{id}")
    public BaseResponse deleteSpecialty(@PathVariable Integer id) {
        return doctorService.deleteDoctor(id);
    }
}
